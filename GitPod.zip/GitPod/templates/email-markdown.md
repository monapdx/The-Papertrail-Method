## Email With Code Block for Body Text

````markdown
|            |             |
| ------------ | ----------- |
| **From:**    |  First Last email@gmailer.com  |
| **To:**      | First Last questions@show.com      |
| **Subject:** | Subject Line Here  |

```text
Body of email goes here.
```

````

## Email Reply With Signature
 
 
````markdown
|||
|---|---|
| **From:** | First Last, Title/Position `<name@show.com>` |
| **To:** | First Last, Title/Position `<redacted@redacted.com>` |
| **Subject:** | Re: Subject Line  |

```text
Body of email goes here.
```

-First Last
**Title/Position**
*Name of Show*
````


## Email With Attachment


````markdown
|              |             |
| ------------ | ----------- |
| **From:**    | First Last, Title `<title@website.com>`    |
| **To:**      | First Last, Title `<name@website.com>`      |
| **Subject:** | Fwd: Subject Line |

```text
Email  body text goes here.
```

- First Last
**Title/Role**
*Show Name*

| ATTACHMENTS | SIZE |
|---|---:|
| 🖼️ **[filename](https://link.com)** | 3 kb |
````
